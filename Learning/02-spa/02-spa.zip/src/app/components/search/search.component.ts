import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Heroe, HeroesService } from '../../services/heroes.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  heroes: Heroe[] = [];
  constructor(private heroesService: HeroesService,
              private activatedRoute: ActivatedRoute,
              private router: Router) {
    
    this.activatedRoute.params.subscribe( params => {
      let term = params["term"];
      this.heroes = this.heroesService.searchHeroes(term);
    });
  }

  ngOnInit() {
  }

  heroInfo(id:number){
    this.router.navigate(['/hero', id]);
  }

}
